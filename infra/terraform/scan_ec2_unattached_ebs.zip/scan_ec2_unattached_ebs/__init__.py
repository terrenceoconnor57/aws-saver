"""Lambda handler for scanning unattached EBS volumes."""

