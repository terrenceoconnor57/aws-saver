"""Scanner modules for AWS resources."""

