"""AWS Saver Bot - Cost-saving automation."""

__version__ = "0.1.0"

